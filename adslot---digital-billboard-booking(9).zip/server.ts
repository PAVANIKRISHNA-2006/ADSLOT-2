import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Lazy initialize Gemini
  const getGemini = () => {
    const key = process.env.GEMINI_API_KEY;
    if (!key) return null;
    return new GoogleGenAI(key).getGenerativeModel({ model: "gemini-1.5-flash" });
  };

  // In-memory storage for demo
  const campaigns: any[] = [];
  const advertiserSubscriptions: Set<string> = new Set(); // Set of email/phone who paid
  const dealerInquiries: any[] = []; // Track which dealer was contacted for which campaign
  const dealers: any[] = [
    { 
      id: 1, 
      name: 'Skyline Media Pvt. Ltd.', 
      areas: 'Hitech City · Gachibowli', 
      stats: ['★ 4.8', '120 screens', 'LED'], 
      tier: 'Premium', 
      email: 'skyline@demo.com', 
      password: 'password123',
      dealerCode: 'DL-SKY-001',
      isSubscribed: true,
      subscriptionExpiry: '2026-12-31'
    },
    { 
      id: 2, 
      name: 'NeonVista Advertising', 
      areas: 'Banjara Hills · Jubilee Hills', 
      stats: ['★ 4.9', '64 screens', 'Premium'], 
      tier: 'Premium', 
      email: 'neon@demo.com', 
      password: 'password123',
      dealerCode: 'DL-NEO-002',
      isSubscribed: true,
      subscriptionExpiry: '2026-10-15'
    },
    { 
      id: 3, 
      name: 'Urban Screens Co.', 
      areas: 'Airport · ORR · Old City', 
      stats: ['★ 4.7', '200 screens', 'Mesh'], 
      tier: 'Nominal', 
      email: 'urban@demo.com', 
      password: 'password123',
      dealerCode: 'DL-URB-003',
      isSubscribed: false,
      subscriptionExpiry: null
    },
    { 
      id: 5, 
      name: 'BudgetBoard Direct', 
      areas: 'Kukatpally · KPHB', 
      stats: ['★ 4.5', '45 screens', 'High Value'], 
      tier: 'Nominal', 
      email: 'budget@demo.com', 
      password: 'password123',
      dealerCode: 'DL-BUD-005',
      isSubscribed: true,
      subscriptionExpiry: '2027-01-01'
    },
    { 
      id: 6, 
      name: 'LocalLink Screens', 
      areas: 'Ameerpet · Secunderabad', 
      stats: ['★ 4.4', '30 screens', 'Express'], 
      tier: 'Nominal', 
      email: 'local@demo.com', 
      password: 'password123',
      dealerCode: 'DL-LOC-006',
      isSubscribed: true,
      subscriptionExpiry: '2027-02-01'
    },
  ];

  app.use(express.json());

  // API Route: Advertiser Subscribe (Unlock Dealers)
  app.post("/api/advertiser/unlock", (req, res) => {
    const { contact } = req.body;
    if (contact) {
      advertiserSubscriptions.add(contact);
      res.json({ success: true, message: "Marketplace Unlocked" });
    } else {
      res.status(400).json({ error: "Contact info required" });
    }
  });

  // API Route: Dealer Login
  app.post("/api/dealers/login", (req, res) => {
    const { email, password } = req.body;
    const dealer = dealers.find(d => d.email === email && d.password === password);
    if (dealer) {
      res.json({ success: true, dealer });
    } else {
      res.status(401).json({ success: false, message: "Invalid credentials" });
    }
  });

  // API Route: Dealer Onboarding
  app.post("/api/dealers", (req, res) => {
    const dealerData = req.body;
    const dealerCode = `DL-${dealerData.companyName.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
    const newDealer = {
      id: dealers.length + 1,
      name: dealerData.companyName,
      email: dealerData.contactEmail,
      password: dealerData.password || 'admin123', // Demo fallback
      areas: dealerData.coveredAreas.join(' · '),
      stats: ['★ 5.0', `${dealerData.screenCount} screens`, dealerData.pricingTier],
      tier: dealerData.pricingTier,
      dealerCode: dealerCode,
      isSubscribed: false,
      subscriptionExpiry: null,
      contact: dealerData.contactEmail
    };
    dealers.push(newDealer);
    console.log("New dealer onboarded:", newDealer);
    res.status(201).json({ success: true, dealer: newDealer });
  });

  // API Route: Contact Dealer (Inquiry)
  app.post("/api/inquiries", (req, res) => {
    const { dealerId, campaignId } = req.body;
    const inquiry = {
      id: dealerInquiries.length + 1,
      dealerId,
      campaignId,
      timestamp: new Date().toISOString(),
      status: 'Pending'
    };
    dealerInquiries.push(inquiry);
    res.json({ success: true, inquiry });
  });

  // API Route: Dealer Dashboard Data
  app.get("/api/dealers/:dealerId/dashboard", (req, res) => {
    const dealerId = parseInt(req.params.dealerId);
    const dealer = dealers.find(d => d.id === dealerId);
    if (!dealer) return res.status(404).json({ error: "Dealer not found" });

    // Find inquiries for this dealer
    const myInquiries = dealerInquiries.filter(i => i.dealerId === dealerId);
    // Populate campaign details
    const populatedInquiries = myInquiries.map(inq => {
      const campaign = campaigns.find(c => c.campaignId === inq.campaignId);
      return { ...inq, campaign };
    });

    res.json({ dealer, inquiries: populatedInquiries });
  });

  // API Route: Dealer Subscription (Mock)
  app.post("/api/dealers/:dealerId/subscribe", (req, res) => {
    const dealerId = parseInt(req.params.dealerId);
    const dealer = dealers.find(d => d.id === dealerId);
    if (dealer) {
      dealer.isSubscribed = true;
      const expiry = new Date();
      expiry.setFullYear(expiry.getFullYear() + 1);
      dealer.subscriptionExpiry = expiry.toISOString().split('T')[0];
      res.json({ success: true, dealer });
    } else {
      res.status(404).json({ error: "Dealer not found" });
    }
  });

  // API Route: AI Ad Assistant
  app.post("/api/ai/suggest", async (req, res) => {
    const { brandName, objective } = req.body;
    const model = getGemini();
    
    if (!model) {
      return res.status(503).json({ error: "AI Service unavailable (Check API Key)" });
    }

    try {
      const prompt = `Generate 3 short, punchy headlines for a digital billboard ad for a brand named "${brandName}". The campaign objective is "${objective}". Keep them under 30 characters each. Return as a JSON array of strings.`;
      const result = await model.generateContent(prompt);
      const text = result.response.text();
      // Basic cleanup for JSON if model includes markdown
      const jsonStr = text.match(/\[.*\]/s)?.[0] || '[]';
      res.json({ suggestions: JSON.parse(jsonStr) });
    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ error: "Failed to generate suggestions" });
    }
  });

  // API Route: Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "AdSlot Backend is live", dealerCount: dealers.length });
  });

  // API Route: Get Dealers
  app.get("/api/dealers", (req, res) => {
    res.json(dealers);
  });

  // API Route: Example Campaign Submission
  app.post("/api/campaigns", (req, res) => {
    const campaignData = req.body;
    campaigns.push(campaignData);
    console.log("Saving new campaign:", campaignData);
    res.status(201).json({ 
      success: true, 
      message: "Campaign received",
      campaignId: `AD-${Math.floor(Math.random() * 900000 + 100000)}` 
    });
  });

  // Vite integration for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    
    // Explicitly handle index.html for SPA fallback in dev
    app.get("*", async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
