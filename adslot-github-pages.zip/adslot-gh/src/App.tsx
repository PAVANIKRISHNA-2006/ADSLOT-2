/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, ChangeEvent } from 'react';
import { 
  ArrowRight, 
  ArrowLeft, 
  Upload, 
  Check, 
  MapPin, 
  Eye, 
  Edit3, 
  Send, 
  Star,
  Zap,
  BarChart3,
  Globe,
  Lock,
  DollarSign,
  User,
  LayoutDashboard,
  Settings,
  LogOut,
  CreditCard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- TYPES ---
type Screen = 's0' | 's1' | 's2' | 's3' | 's4' | 's5' | 's6' | 's7' | 's8' | 's9' | 's10' | 's11' | 's12';

interface CampaignState {
  adType: string;
  areas: string[];
  slots: number;
  coupon: string;
  couponDiscount: number;
  name: string;
  phone: string;
  email: string;
  brandNotes: string;
  selections: number[]; // indices of dots selected on map
  campaignId: string;
  displaySize: string;
  displayType: string;
  material: string;
  duration: string;
  period: string;
}

interface Dealer {
  id: number;
  name: string;
  areas: string;
  stats: string[];
  tier: string;
  contact?: string;
  dealerCode?: string;
  email?: string;
  isSubscribed?: boolean;
  subscriptionExpiry?: string | null;
}

const SCREENS: Screen[] = ['s1', 's2', 's3', 's4', 's5', 's6', 's7', 's8'];
const SCREEN_LABELS = ['Profile', 'Welcome', 'Creative', 'Locations', 'Preview', 'Studio', 'Review', 'Connect'];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('s0');
  const [state, setState] = useState<CampaignState>({
    adType: 'Brand Awareness',
    areas: ['Hitech City'],
    slots: 0,
    coupon: '',
    couponDiscount: 0,
    name: '',
    phone: '',
    email: '',
    brandNotes: '',
    selections: [],
    campaignId: '',
    displaySize: '96 × 48 in — Large Billboard',
    displayType: 'LED Full Colour',
    material: 'Vinyl Flex (Outdoor)',
    duration: '15 seconds',
    period: '1 Month',
  });

  const [toast, setToast] = useState<{ msg: string; isErr: boolean } | null>(null);
  const [dots, setDots] = useState<number[]>([]); // indices of dots that are active screens
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [dealers, setDealers] = useState<Dealer[]>([]);
  const [dealerFilter, setDealerFilter] = useState<'All' | 'Premium' | 'Nominal'>('All');

  const [dealerOnboardState, setDealerOnboardState] = useState({
    companyName: '',
    contactEmail: '',
    contactPhone: '',
    screenCount: 1,
    coveredAreas: [] as string[],
    pricingTier: 'Nominal',
    password: 'password123'
  });

  const [onboardedDealer, setOnboardedDealer] = useState<Dealer | null>(null);
  const [loggedInDealer, setLoggedInDealer] = useState<Dealer | null>(null);
  const [dashboardData, setDashboardData] = useState<{ dealer: Dealer; inquiries: any[] } | null>(null);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [isMarketplaceUnlocked, setIsMarketplaceUnlocked] = useState(false);

  // Editor State
  const [editorElements, setEditorElements] = useState<any[]>([]);
  const [selectedElIdx, setSelectedElIdx] = useState<number | null>(null);
  const [activeTool, setActiveTool] = useState<string>('text');
  const [editorClr, setEditorClr] = useState('#ffffff');
  const [canvasBg, setCanvasBg] = useState('#16162a');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // --- LOCAL IN-MEMORY DATA (replaces Express backend for static hosting) ---
  const LOCAL_DEALERS: Dealer[] = [
    { id: 1, name: 'Skyline Media Pvt. Ltd.', areas: 'Hitech City · Gachibowli', stats: ['★ 4.8', '120 screens', 'LED'], tier: 'Premium', email: 'skyline@demo.com', dealerCode: 'DL-SKY-001', isSubscribed: true, subscriptionExpiry: '2026-12-31' },
    { id: 2, name: 'NeonVista Advertising', areas: 'Banjara Hills · Jubilee Hills', stats: ['★ 4.9', '64 screens', 'Premium'], tier: 'Premium', email: 'neon@demo.com', dealerCode: 'DL-NEO-002', isSubscribed: true, subscriptionExpiry: '2026-10-15' },
    { id: 3, name: 'Urban Screens Co.', areas: 'Airport · ORR · Old City', stats: ['★ 4.7', '200 screens', 'Mesh'], tier: 'Nominal', email: 'urban@demo.com', dealerCode: 'DL-URB-003', isSubscribed: false, subscriptionExpiry: null },
    { id: 5, name: 'BudgetBoard Direct', areas: 'Kukatpally · KPHB', stats: ['★ 4.5', '45 screens', 'High Value'], tier: 'Nominal', email: 'budget@demo.com', dealerCode: 'DL-BUD-005', isSubscribed: true, subscriptionExpiry: '2027-01-01' },
    { id: 6, name: 'LocalLink Screens', areas: 'Ameerpet · Secunderabad', stats: ['★ 4.4', '30 screens', 'Express'], tier: 'Nominal', email: 'local@demo.com', dealerCode: 'DL-LOC-006', isSubscribed: true, subscriptionExpiry: '2027-02-01' },
  ];
  const LOCAL_PASSWORDS: Record<string, string> = {
    'skyline@demo.com': 'password123',
    'neon@demo.com': 'password123',
    'urban@demo.com': 'password123',
    'budget@demo.com': 'password123',
    'local@demo.com': 'password123',
  };

  const fetchDealers = () => {
    setDealers(LOCAL_DEALERS);
  };

  const handleDealerLogin = () => {
    const dealer = LOCAL_DEALERS.find(d => d.email === loginForm.email);
    if (dealer && LOCAL_PASSWORDS[loginForm.email] === loginForm.password) {
      setLoggedInDealer(dealer);
      showToast("Login Successful! 👔");
      setDashboardData({ dealer, inquiries: [] });
      nav('s10');
    } else {
      showToast("Invalid credentials", true);
    }
  };

  const handleSubscribe = () => {
    if (!loggedInDealer) return;
    const expiry = new Date();
    expiry.setFullYear(expiry.getFullYear() + 1);
    const updated = { ...loggedInDealer, isSubscribed: true, subscriptionExpiry: expiry.toISOString().split('T')[0] };
    setLoggedInDealer(updated);
    setDashboardData(prev => prev ? { ...prev, dealer: updated } : null);
    showToast("Subscription successful! Premium features unlocked. 🎉");
  };

  const handleUnlockMarketplace = () => {
    setIsMarketplaceUnlocked(true);
    showToast("Access Unlocked! Viewing 100% of dealers. 🚀");
  };

  const contactDealer = (_dealerId: number, _campaignId: string) => {
    showToast("Inquiry sent to dealer! 📬");
  };

  const submitDealerOnboarding = () => {
    if (!dealerOnboardState.companyName || !dealerOnboardState.contactEmail) {
      return showToast("Company name and email are required", true);
    }
    const dealerCode = `DL-${dealerOnboardState.companyName.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
    const newDealer: Dealer = {
      id: LOCAL_DEALERS.length + 10,
      name: dealerOnboardState.companyName,
      email: dealerOnboardState.contactEmail,
      areas: dealerOnboardState.coveredAreas.join(' · '),
      stats: ['★ 5.0', `${dealerOnboardState.screenCount} screens`, dealerOnboardState.pricingTier],
      tier: dealerOnboardState.pricingTier,
      dealerCode,
      isSubscribed: false,
      subscriptionExpiry: null,
    };
    setOnboardedDealer(newDealer);
    showToast("Dealer onboarded successfully! 🏙️");
    nav('s12');
  };

  const getAiSuggestions = async () => {
    if (!state.name) return showToast("Enter your name/brand first", true);
    setIsAiLoading(true);
    // Static fallback suggestions — no backend needed for static hosting
    const fallbacks: Record<string, string[]> = {
      'Brand Awareness': [`${state.name}: Built Different`, `See ${state.name} Live`, `${state.name} — Now Here`],
      'Product Launch': [`New from ${state.name}`, `${state.name} Just Dropped`, `Discover ${state.name}`],
      'Event Promo': [`${state.name} Is Live`, `Don't Miss ${state.name}`, `${state.name} — This Weekend`],
      'Offers & Deals': [`${state.name} Sale On`, `Save Big at ${state.name}`, `${state.name} — Best Deals`],
      'Real Estate': [`${state.name} Properties`, `Live at ${state.name}`, `${state.name} — Your New Home`],
      'Political': [`Vote ${state.name}`, `${state.name} For Change`, `${state.name} — Your Voice`],
    };
    await new Promise(r => setTimeout(r, 700)); // brief loading feel
    const suggestions = fallbacks[state.adType] || [`${state.name} — On Every Screen`, `Choose ${state.name}`, `${state.name} Is Here`];
    setAiSuggestions(suggestions);
    showToast("AI Suggestions generated!");
    setIsAiLoading(false);
  };

  const addEditorElement = (e: any) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newEl = {
      id: Date.now(),
      type: activeTool,
      x, y,
      text: state.name || 'Your Ad Text',
      color: editorClr,
      size: 24,
      opacity: 1,
    };
    
    setEditorElements([...editorElements, newEl]);
    setSelectedElIdx(editorElements.length);
  };

  useEffect(() => {
    const screenPos = [3, 8, 14, 22, 31, 38, 46, 55, 62, 70, 77, 83, 88, 92, 17, 27, 35, 51, 65, 73];
    setDots(screenPos);

    // Load dealers from local data (static hosting, no backend)
    fetchDealers();
  }, []);

  const nav = (target: Screen) => {
    setCurrentScreen(target);
    window.scrollTo(0, 0);
  };

  const showToast = (msg: string, isErr = false) => {
    setToast({ msg, isErr });
    setTimeout(() => setToast(null), 3000);
  };

  const handleApplyCoupon = (code: string) => {
    const v = code.trim().toUpperCase();
    if (v === 'ADSLOT20') {
      setState(prev => ({ ...prev, coupon: 'ADSLOT20', couponDiscount: 20 }));
      showToast('20% discount applied! 🎉');
    } else if (v === 'LAUNCH10') {
      setState(prev => ({ ...prev, coupon: 'LAUNCH10', couponDiscount: 10 }));
      showToast('10% discount applied! 🎉');
    } else {
      showToast('Invalid coupon code', true);
    }
  };

  const calculatePrice = () => {
    const n = state.areas.length;
    const s = state.slots;
    let price = n * 8000 + s * 2500;
    if (state.couponDiscount > 0) {
      price = Math.round(price * (1 - state.couponDiscount / 100));
    }
    return price;
  };

  const toggleDot = (idx: number) => {
    setState(prev => {
      const isSelected = prev.selections.includes(idx);
      const newSelections = isSelected 
        ? prev.selections.filter(i => i !== idx)
        : [...prev.selections, idx];
      return { ...prev, selections: newSelections, slots: newSelections.length };
    });
  };

  const toggleArea = (area: string) => {
    setState(prev => {
      const isIncluded = prev.areas.includes(area);
      const newAreas = isIncluded 
        ? prev.areas.filter(a => a !== area)
        : [...prev.areas, area];
      return { ...prev, areas: newAreas };
    });
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      showToast('File uploaded successfully!');
    }
  };

  const submitCampaign = () => {
    const campId = 'AD-' + Math.floor(Math.random() * 900000 + 100000);
    setState(prev => ({ ...prev, campaignId: campId }));
    showToast('Campaign submitted! 🚀');
    nav('s8');
  };

  const resetAll = () => {
    setState({
      adType: 'Brand Awareness',
      areas: ['Hitech City'],
      slots: 0,
      coupon: '',
      couponDiscount: 0,
      name: '',
      phone: '',
      email: '',
      brandNotes: '',
      selections: [],
      campaignId: '',
      displaySize: '96 × 48 in — Large Billboard',
      displayType: 'LED Full Colour',
      material: 'Vinyl Flex (Outdoor)',
      duration: '15 seconds',
      period: '1 Month',
    });
    setUploadedFile(null);
    setPreviewUrl(null);
    nav('s0');
  };

  const renderSteps = (id: Screen) => {
    const idx = SCREENS.indexOf(id);
    return (
      <div className="tsteps">
        {SCREENS.map((v, i) => (
          <div key={v} className={`ts ${i < idx ? 'ts-done' : i === idx ? 'ts-cur' : ''}`}>
             {i < idx ? '✓ ' : ''}{SCREEN_LABELS[i]}
          </div>
        ))}
      </div>
    );
  };

  // --- SUB-COMPONENTS ---
  const TopBar = ({ id }: { id: Screen }) => (
    <div className="topbar">
      <div className="tlogo">AdSlot</div>
      {renderSteps(id)}
      <div className="tright">Step {SCREENS.indexOf(id) + 1} / {SCREENS.length}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white selection:bg-lime selection:text-black">
      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            className={`fixed bottom-7 right-7 z-[9999] bg-dark-3 border border-white/13 border-l-[3px] ${toast.isErr ? 'border-l-red-500' : 'border-l-lime'} rounded-r p-4 font-medium shadow-2xl max-w-[300px]`}
          >
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- S0: LANDING --- */}
      {currentScreen === 's0' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col min-h-screen">
          <nav className="lnav flex items-center justify-between px-12 h-[66px] border-b border-white/7 shrink-0 relative z-10">
            <div className="tlogo scale-110">AdSlot</div>
            <div className="hidden md:flex gap-7 text-sm text-white/40">
              <span className="cursor-pointer hover:text-white transition-colors">Pricing</span>
              <span className="cursor-pointer hover:text-white transition-colors">Locations</span>
              <span className="cursor-pointer hover:text-white transition-colors" onClick={() => nav('s9')}>Dealers: Partner with us</span>
            </div>
            <button className="btn btn-p" onClick={() => nav('s1')}>Start Campaign <ArrowRight className="w-4 h-4" /></button>
          </nav>
          
          <div className="flex-1 grid md:grid-cols-2 overflow-hidden">
            <div className="p-13 md:p-16 border-r border-white/7 flex flex-col justify-between relative">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[length:56px_56px] pointer-events-none" />
              <div className="relative z-10">
                <div className="eyebrow flex items-center gap-2 bg-lime/10 border border-lime/20 rounded-full px-3.5 py-1.5 text-[11px] font-bold tracking-widest uppercase text-lime mb-6 w-fit">
                  <div className="w-2 h-2 rounded-full bg-lime animate-pulse-ring" />
                  Live · 47 active campaigns
                </div>
                <h1 className="font-syne text-5xl md:text-7xl font-extrabold leading-[0.93] tracking-tighter mb-5">
                  YOUR<br />AD ON<br /><span className="text-lime italic">EVERY</span><br />SCREEN
                </h1>
                <p className="text-white/45 text-base md:text-lg leading-relaxed max-w-[360px] mb-8">
                  Book digital billboard slots across city landmarks. Real screens. Real people. Real results.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button className="btn btn-p px-10 py-4 text-base" onClick={() => nav('s1')}>Start campaign <ArrowRight className="w-5 h-5" /></button>
                  <button className="btn btn-s" onClick={() => nav('s4')}>View locations</button>
                </div>
              </div>
              
              <div className="flex border-t border-white/7 pt-7 mt-12 relative z-10">
                <div className="flex-1 border-r border-white/7">
                  <div className="font-syne text-3xl font-extrabold text-lime">500+</div>
                  <div className="text-[11px] text-white/40 mt-0.5 tracking-tight">Active screens</div>
                </div>
                <div className="flex-1 border-r border-white/7 pl-6">
                  <div className="font-syne text-3xl font-extrabold text-lime">12</div>
                  <div className="text-[11px] text-white/40 mt-0.5 tracking-tight">Areas covered</div>
                </div>
                <div className="flex-1 pl-6">
                  <div className="font-syne text-3xl font-extrabold text-lime">3M+</div>
                  <div className="text-[11px] text-white/40 mt-0.5 tracking-tight">Daily reach</div>
                </div>
              </div>
            </div>

            <div className="bg-dark flex items-center justify-center p-10 relative overflow-hidden">
               <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(184,255,53,0.06)_0%,transparent_65%)]" />
               
               <div className="relative z-10 flex flex-col items-center max-w-full">
                  <div className="flex items-end justify-center gap-2 mb-0">
                    <div className="bg-dark-2 border border-white/5 w-12 h-28 rounded-t" />
                    <div className="bg-dark-2 border border-white/5 w-10 h-20 rounded-t" />
                    <div className="flex flex-col items-center">
                      <div className="w-[240px] aspect-[16/5] bg-dark-4 border-2 border-white/15 rounded-lg overflow-hidden relative flex items-center justify-center">
                        <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-lime/60 to-transparent animate-scan" />
                        <div className="text-center p-4">
                          <div className="font-syne text-xl font-extrabold tracking-widest uppercase">YOUR BRAND</div>
                          <div className="text-[8px] tracking-[0.2em] text-cyan uppercase mt-1">Hitech City · Live Traffic</div>
                        </div>
                      </div>
                      <div className="w-1 h-10 bg-dark-3 border-x border-white/5" />
                      <div className="w-[340px] h-5 bg-dark-2 border-t-2 border-white/5 relative overflow-hidden rounded-b">
                         <div className="absolute inset-0 flex items-center animate-road">
                            <div className="w-[300%] h-0.5 bg-[repeating-linear-gradient(90deg,rgba(255,255,255,0.14)_0,rgba(255,255,255,0.14)_20px,transparent_20px,transparent_40px)]" />
                         </div>
                      </div>
                    </div>
                    <div className="bg-dark-2 border border-white/5 w-14 h-36 rounded-t" />
                    <div className="bg-dark-2 border border-white/5 w-9 h-24 rounded-t" />
                  </div>

                  <div className="absolute bottom-[40%] -left-10 bg-dark-3 border border-white/13 rounded-R p-3 shadow-xl">
                    <div className="text-[10px] font-semibold text-white/40 uppercase tracking-widest">Slots from</div>
                    <div className="font-syne text-2xl font-extrabold text-red-500 mt-1">₹8K/mo</div>
                  </div>
                  <div className="absolute bottom-[30%] -right-10 bg-dark-3 border border-white/13 rounded-R p-4 shadow-xl">
                    <div className="text-[10px] font-semibold text-white/40 uppercase tracking-widest">Reach</div>
                    <div className="font-syne text-2xl font-extrabold text-cyan mt-1">3M+</div>
                  </div>
               </div>
            </div>
          </div>

          <div className="bg-lime text-black py-3.5 px-12 flex items-center justify-between gap-5 text-[13px] font-bold tracking-tight">
            <span className="flex items-center gap-2 truncate">
              <Zap className="w-4 h-4" /> 
              LIVE NOW · 47 active campaigns · 3 slots available in Hitech City · Book before they're gone
            </span>
            <button className="bg-black text-lime border-none rounded-full px-5 py-2 hover:bg-dark-4 transition-colors whitespace-nowrap" onClick={() => nav('s1')}>
              Book a slot →
            </button>
          </div>
        </motion.div>
      )}

      {/* --- S1: SIGNUP --- */}
      {currentScreen === 's1' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s1" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Get started</div>
            <div className="ptitle">Create your profile</div>
            <div className="psub">Tell us who you are and what kind of campaign you're running.</div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="field">
                <label>Full name</label>
                <input value={state.name} onChange={e => setState(s => ({ ...s, name: e.target.value }))} type="text" placeholder="Raj Sharma" />
              </div>
              <div className="field">
                <label>Mobile number</label>
                <input value={state.phone} onChange={e => setState(s => ({ ...s, phone: e.target.value }))} type="tel" placeholder="+91 98765 43210" />
              </div>
            </div>
            <div className="field">
              <label>Email address</label>
              <input value={state.email} onChange={e => setState(s => ({ ...s, email: e.target.value }))} type="email" placeholder="raj@yourcompany.com" />
            </div>

            <div className="field mt-4">
              <label className="flex items-center justify-between">
                Campaign type
                <button 
                  onClick={getAiSuggestions}
                  disabled={isAiLoading}
                  className="text-[10px] bg-lime/10 text-lime border border-lime/20 px-2 py-1 rounded flex items-center gap-1 hover:bg-lime/20 transition-all font-bold disabled:opacity-50"
                >
                  <Zap className={`w-3 h-3 ${isAiLoading ? 'animate-pulse' : ''}`} /> {isAiLoading ? 'Analyzing...' : 'AI Strategy Support'}
                </button>
              </label>
              {aiSuggestions.length > 0 && (
                <div className="mb-4 flex flex-wrap gap-2 animate-in fade-in slide-in-from-top-2 pt-2">
                   {aiSuggestions.map((s, i) => (
                     <div 
                      key={i} 
                      onClick={() => { setState(prev => ({ ...prev, name: s })); showToast("Headline updated!") }}
                      className="text-[11px] bg-dark-4 border border-white/10 rounded px-2.5 py-1 text-white/60 cursor-pointer hover:border-lime hover:text-lime transition-all"
                     >
                       "{s}"
                     </div>
                   ))}
                </div>
              )}
              <div className="atgrid grid-cols-2 sm:grid-cols-3">
                {['Brand Awareness', 'Product Launch', 'Event Promo', 'Offers & Deals', 'Real Estate', 'Political'].map(type => (
                  <div 
                    key={type}
                    onClick={() => setState(s => ({ ...s, adType: type }))}
                    className={`atcard ${state.adType === type ? 'atcard-sel' : ''}`}
                  >
                    <div className="text-xl mb-1.5 opacity-80">
                      {type === 'Brand Awareness' && '★'}
                      {type === 'Product Launch' && '◈'}
                      {type === 'Event Promo' && '◉'}
                      {type === 'Offers & Deals' && '◎'}
                      {type === 'Real Estate' && '⬡'}
                      {type === 'Political' && '◇'}
                    </div>
                    <div className={`text-[13px] font-semibold mb-0.5 ${state.adType === type ? 'text-lime' : ''}`}>{type}</div>
                    <div className="text-[11px] text-white/40">
                      {type === 'Brand Awareness' && 'Build recognition'}
                      {type === 'Product Launch' && 'New arrival push'}
                      {type === 'Event Promo' && 'Drive foot traffic'}
                      {type === 'Offers & Deals' && 'Flash sale push'}
                      {type === 'Real Estate' && 'Property listings'}
                      {type === 'Political' && 'Voter outreach'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="field mt-4">
              <label>Coupon code <span className="text-white/20 font-normal lowercase">(e.g. ADSLOT20)</span></label>
              <div className="flex gap-2.5">
                <input 
                  defaultValue={state.coupon}
                  id="coupon-input"
                  className="flex-1" 
                  type="text" 
                  placeholder="Enter code" 
                />
                <button 
                  onClick={() => handleApplyCoupon((document.getElementById('coupon-input') as HTMLInputElement).value)}
                  className={`px-5 py-2 bg-dark-4 border border-white/13 rounded-r text-[13px] font-semibold transition-all hover:border-lime hover:text-lime ${state.couponDiscount > 0 ? 'border-lime text-lime' : ''}`}
                >
                  {state.couponDiscount > 0 ? 'Applied' : 'Apply'}
                </button>
              </div>
            </div>

            <div className="divider" />
            <div className="flex gap-3 mt-8">
              <button className="btn btn-g" onClick={() => nav('s0')}><ArrowLeft className="w-4 h-4" /> Back</button>
              <button className="btn btn-p" onClick={() => {
                if (!state.name || !state.phone) return showToast('Name and phone are required', true);
                nav('s2');
              }}>Continue <ArrowRight className="w-4 h-4" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S2: QUOTE / WELCOME --- */}
      {currentScreen === 's2' && (
        <div className="flex flex-col min-h-screen items-center justify-center relative overflow-hidden py-10">
          <TopBar id="s2" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[radial-gradient(circle,rgba(184,255,53,0.06)_0%,transparent_65%)] pointer-events-none" />
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="relative z-10 text-center max-w-[620px] px-8 flex flex-col items-center">
            <div className="bg-lime/10 border border-lime/20 rounded-full py-2 px-6 text-sm font-semibold tracking-wide text-lime mb-8">
              Welcome aboard, {state.name.split(' ')[0]}!
            </div>
            <div className="font-syne text-[140px] leading-[0.75] text-white/5 mb-[-10px] select-none">"</div>
            <h2 className="font-syne text-3xl md:text-5xl font-extrabold leading-[1.1] tracking-tight mb-5 px-4">
              Your brand deserves to be<br />seen by <span className="text-lime">millions</span>, not buried<br />in a scrollable feed.
            </h2>
            <div className="text-sm text-white/40 mb-3 tracking-wide">— AdSlot Team</div>
            <div className="font-syne text-2xl font-bold text-lime mb-12">{state.name} · {state.adType}</div>
            
            <div className="flex gap-12 mb-12">
               <div className="text-center">
                  <div className="font-syne text-3xl font-extrabold">500+</div>
                  <div className="text-[11px] text-white/40 uppercase tracking-widest mt-1">Screens</div>
               </div>
               <div className="text-center">
                  <div className="font-syne text-3xl font-extrabold">3M+</div>
                  <div className="text-[11px] text-white/40 uppercase tracking-widest mt-1">Daily reach</div>
               </div>
               <div className="text-center">
                  <div className="font-syne text-3xl font-extrabold">₹12</div>
                  <div className="text-[11px] text-white/40 uppercase tracking-widest mt-1">Avg CPM</div>
               </div>
            </div>

            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s1')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-p text-base px-10 py-4" onClick={() => nav('s3')}>Build my ad <ArrowRight className="w-5 h-5" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S3: UPLOAD --- */}
      {currentScreen === 's3' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s3" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Creative</div>
            <div className="ptitle">Upload your ad</div>
            <div className="psub">Drop your file and configure display specifications.</div>

            <input type="file" id="file-upload" className="hidden" onChange={handleFileUpload} accept="image/*,video/mp4,.pdf,.gif" />
            <div 
              onClick={() => document.getElementById('file-upload')?.click()}
              className={`dz ${uploadedFile ? 'dz-ok' : ''}`}
            >
              <Upload className={`w-8 h-8 mx-auto mb-2 opacity-70 ${uploadedFile ? 'text-lime' : ''}`} />
              <div className="text-[15px] font-semibold mb-1">{uploadedFile ? uploadedFile.name : 'Drop your file here or click to browse'}</div>
              <div className="text-[12px] text-white/40">
                {uploadedFile 
                  ? `${(uploadedFile.size / 1024 / 1024).toFixed(2)} MB · Uploaded successfully`
                  : 'JPG · PNG · MP4 · GIF · PDF · HTML5 — Max 100MB'}
              </div>
              {previewUrl && (
                <div className="absolute inset-0 opacity-10 pointer-events-none">
                   <img src={previewUrl} className="w-full h-full object-cover" alt="Preview" />
                </div>
              )}
            </div>

            <div className="field mt-4">
              <label>Accepted formats</label>
              <div className="flex flex-wrap gap-2">
                {['JPG / PNG', 'MP4 Video', 'Animated GIF', 'PDF', 'HTML5', 'WEBP'].map(f => (
                  <div key={f} className={`py-1.5 px-4 rounded-full border-[1.5px] border-white/10 bg-dark-3 text-xs font-semibold tracking-wide transition-all ${f === 'JPG / PNG' ? 'bg-lime/10 border-lime/40 text-lime' : 'text-white/40 hover:text-white'}`}>
                    {f}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 mt-6">
              {[
                { label: 'Display size', key: 'displaySize', options: ['96 × 48 in — Large Billboard', '48 × 24 in — Medium', '72 × 24 in — Highway', '24 × 12 in — Street Panel'] },
                { label: 'Display type', key: 'displayType', options: ['LED Full Colour', 'LCD Backlit', 'OLED Premium', 'Backlit Vinyl', 'Mesh Banner'] },
                { label: 'Campaign period', key: 'period', options: ['1 Week', '2 Weeks', '1 Month', '3 Months', '6 Months'] },
                { label: 'Material', key: 'material', options: ['Vinyl Flex (Outdoor)', 'Backlit Film', 'PVC Banner', 'Mesh (Wind-resistant)', 'Digital Screen Only'] },
                { label: 'Slot duration', key: 'duration', options: ['10 seconds', '15 seconds', '30 seconds', '60 seconds'] },
              ].map(group => (
                <div key={group.label} className="bg-dark-3 border border-white/10 rounded-r p-3.5">
                  <div className="text-[10px] font-semibold uppercase tracking-widest text-white/40 mb-1.5">{group.label}</div>
                  <select 
                    value={(state as any)[group.key]} 
                    onChange={e => setState(s => ({ ...s, [group.key]: e.target.value }))}
                    className="bg-transparent border-none text-[13px] font-medium text-white w-full outline-none cursor-pointer"
                  >
                    {group.options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
              ))}
            </div>

            <div className="field mt-6">
              <label>Brand notes</label>
              <textarea 
                value={state.brandNotes}
                onChange={e => setState(s => ({ ...s, brandNotes: e.target.value }))}
                placeholder="Logo position, colour guidelines, exclusion zones, any specific instructions for placement…"
                className="resize-none h-24"
              />
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s2')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-p" onClick={() => nav('s4')}>Choose locations <ArrowRight className="w-4 h-4" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S4: LOCATIONS --- */}
      {currentScreen === 's4' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s4" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Locations</div>
            <div className="ptitle">Pick your screens</div>
            <div className="psub">Select areas then tap individual screen slots on the map. Pricing updates live.</div>

            <div className="field">
              <label>Areas</label>
              <div className="flex flex-wrap gap-2">
                {[
                  'Hitech City', 'Banjara Hills', 'Jubilee Hills', 
                  'KPHB Colony', 'Ameerpet', 'Gachibowli', 
                  'Secunderabad', 'Kukatpally', 'Old City'
                ].map(area => (
                  <div 
                    key={area}
                    onClick={() => toggleArea(area)}
                    className={`area ${state.areas.includes(area) ? 'area-on' : ''}`}
                  >
                    {area}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-dark-2 border border-white/7 rounded-R p-6 mb-6">
               <div className="text-[11px] font-semibold tracking-widest uppercase text-white/40 mb-4 flex items-center gap-2">
                 <Globe className="w-3.5 h-3.5" /> Screen slots — highlighted dots are available screens
               </div>
               <div className="grid grid-cols-12 gap-1.5">
                  {Array.from({ length: 108 }).map((_, i) => {
                    const isScreen = dots.includes(i);
                    const isSelected = state.selections.includes(i);
                    return (
                      <div 
                        key={i} 
                        onClick={() => isScreen && toggleDot(i)}
                        className={`mdot ${isScreen ? 'mdot-sc' : ''} ${isSelected ? 'mdot-sc-on' : ''}`}
                      />
                    );
                  })}
               </div>
            </div>

            <div className="bg-dark-2 border border-white/7 rounded-R p-6 md:p-8 flex items-center justify-between gap-6">
              <div>
                <div className="text-white/55 text-sm leading-relaxed">
                  <strong className="text-white text-[15px]">{state.areas.length} area{state.areas.length!==1?'s':''} · {state.slots} slot{state.slots!==1?'s':''}</strong><br />
                  Estimated daily reach: <span className="text-lime">{ (state.areas.length * 45000 + state.slots * 8000).toLocaleString() }+ </span>
                </div>
              </div>
              <div className="font-syne text-5xl font-extrabold tracking-tight text-lime leading-none">
                ₹{calculatePrice().toLocaleString()}
              </div>
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s3')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-p" onClick={() => nav('s5')}>Preview mockup <ArrowRight className="w-4 h-4" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S5: MOCKUP --- */}
      {currentScreen === 's5' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s5" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg max-w-[860px]">
            <div className="slabel">Preview</div>
            <div className="ptitle">Your ad in the wild</div>
            <div className="psub">See how your campaign looks across selected locations.</div>

            <div className="bg-dark-2 rounded-R overflow-hidden mb-6 border border-white/5">
              <div className="px-11 pt-8 flex items-end gap-3 min-h-[220px]">
                <div className="bg-white/5 border border-white/10 w-12 h-28 rounded-t" />
                <div className="bg-white/5 border border-white/10 w-10 h-20 rounded-t" />
                <div className="flex-1 flex flex-col items-center">
                  <div className="w-[280px] aspect-[16/5] bg-dark border-[2.5px] border-white/20 rounded-lg overflow-hidden relative flex items-center justify-center p-3">
                    <div className="absolute inset-0 bg-lime/5 opacity-40 animate-scan" />
                    {previewUrl ? (
                      <img src={previewUrl} className="max-w-full h-full object-contain" alt="Ad" />
                    ) : (
                      <div className="text-center">
                        <div className="font-syne text-2xl font-extrabold tracking-widest uppercase truncate">{state.name || 'YOUR BRAND'}</div>
                        <div className="text-[8px] tracking-[0.2em] text-cyan uppercase mt-1">Live from Hitech City</div>
                      </div>
                    )}
                  </div>
                  <div className="w-1 h-10 bg-white/10" />
                </div>
                <div className="bg-white/5 border border-white/10 w-14 h-32 rounded-t" />
                <div className="bg-white/5 border border-white/10 w-9 h-24 rounded-t" />
                <div className="bg-white/5 border border-white/10 w-16 h-40 rounded-t" />
              </div>
              <div className="h-5 bg-black/40 border-t border-white/10 relative overflow-hidden animate-road">
                 <div className="absolute inset-0 w-[300%] h-0.5 bg-[repeating-linear-gradient(90deg,rgba(255,255,255,0.14)_0,rgba(255,255,255,0.14)_20px,transparent_20px,transparent_40px)] top-1/2 -translate-y-1/2" />
              </div>
              <div className="p-7 flex border-t border-white/5">
                 {[
                   { label: 'Impressions/day', value: ((state.areas.length * 45000 + state.slots * 8000) / 1000).toFixed(0) + 'K' },
                   { label: 'CPM', value: '₹12' },
                   { label: 'Morning Peak', value: '8–11am' },
                   { label: 'Evening Peak', value: '5–9pm' },
                   { label: 'Slot duration', value: state.duration.replace(' seconds', 's') },
                 ].map(s => (
                   <div key={s.label} className="flex-1 text-center px-3 border-r border-white/5 last:border-r-0">
                      <span className="font-syne text-xl md:text-2xl font-extrabold text-lime block">{s.value}</span>
                      <span className="text-[10px] text-white/40 uppercase tracking-widest">{s.label}</span>
                   </div>
                 ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-8">
               {['Hitech Junction', 'Outer Ring Road', 'Jubilee Checkpost'].map((loc, i) => (
                 <div key={loc} className="bg-dark-2 rounded-r overflow-hidden border border-white/10 group cursor-pointer hover:border-white/20 transition-all">
                    <div className="aspect-[16/6] bg-dark flex items-center justify-center p-2 relative">
                       {previewUrl ? (
                         <img src={previewUrl} className="w-full h-full object-cover rounded opacity-30" alt="sm" />
                       ) : (
                         <div className="font-syne text-[11px] font-bold text-white/20 text-center uppercase">
                           {(state.name || 'YOUR BRAND')}<br />
                           <span className="text-[7px] text-cyan tracking-widest font-normal">LIVE PREVIEW</span>
                         </div>
                       )}
                    </div>
                    <div className="p-2.5 text-[10px] text-white/40 uppercase tracking-widest">{loc}</div>
                 </div>
               ))}
            </div>

            <div className="divider" />
            <div className="flex flex-wrap gap-3">
               <button className="btn btn-g" onClick={() => nav('s4')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-s" onClick={() => nav('s6')}><Edit3 className="w-4 h-4" /> Edit creative (Studio)</button>
               <button className="btn btn-p" onClick={() => nav('s7')}>Finalize campaign <ArrowRight className="w-4 h-4" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S6: STUDIO (Functional!) --- */}
      {currentScreen === 's6' && (
        <div className="flex flex-col min-h-screen">
          <div className="topbar">
            <div className="tlogo">AdSlot</div>
            <div className="text-xs text-white/40 font-semibold tracking-wider uppercase">Creative Studio</div>
            <div className="tright">Studio Tools</div>
          </div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pgw">
            <div className="slabel">Studio</div>
            <div className="ptitle">Creative Canvas</div>
            <div className="psub">Design your billboard ad in real-time. Click the canvas to place elements.</div>
            
            <div className="grid md:grid-cols-[160px_1fr_200px] gap-4 h-[420px] mb-8">
               <div className="bg-dark-2 border border-white/7 rounded-R p-4 flex flex-col gap-2 overflow-y-auto">
                  <div className="text-[10px] font-bold uppercase text-white/30 px-1 mb-2">Tools</div>
                  {['text', 'shape', 'star', 'badge', 'qr'].map(t => (
                    <div 
                      key={t} 
                      onClick={() => setActiveTool(t)}
                      className={`p-3 border rounded-r text-[12px] font-bold cursor-pointer transition-all flex items-center gap-2 capitalize ${activeTool === t ? 'bg-lime/10 border-lime/40 text-lime' : 'bg-dark-3 border-white/5 text-white/40 hover:bg-dark-4'}`}
                    >
                      {t === 'text' && 'T'} {t === 'shape' && '■'} {t === 'star' && '★'} {t === 'badge' && '◈'} {t === 'qr' && '▦'} {t}
                    </div>
                  ))}
                  <div className="h-px bg-white/5 my-2" />
                  <button onClick={() => setEditorElements([])} className="text-[11px] text-red-500/60 font-bold hover:text-red-500 p-2 border border-red-500/10 rounded">Clear Canvas</button>
               </div>

               <div 
                  className="bg-dark border border-white/7 rounded-R relative overflow-hidden transition-colors cursor-crosshair h-full"
                  style={{ backgroundColor: canvasBg }}
                  onClick={addEditorElement}
                >
                  {/* Grid overlay */}
                  <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[length:24px_24px] pointer-events-none" />
                  
                  {editorElements.map((el, i) => (
                    <div 
                      key={el.id}
                      onClick={(e) => { e.stopPropagation(); setSelectedElIdx(i) }}
                      style={{ 
                        position: 'absolute', 
                        left: el.x, 
                        top: el.y, 
                        color: el.color, 
                        fontSize: el.size,
                        opacity: el.opacity,
                        transform: 'translate(-50%, -50%)',
                        cursor: 'move',
                        padding: '4px',
                        outline: selectedElIdx === i ? '1px dashed #b8ff35' : 'none'
                      }}
                      className="select-none font-syne font-bold"
                    >
                      {el.type === 'text' && el.text}
                      {el.type === 'shape' && <div className="w-20 h-10 rounded border" style={{ backgroundColor: el.color }} />}
                      {el.type === 'star' && <Star fill={el.color} className="w-10 h-10" />}
                      {el.type === 'badge' && <div className="bg-white/10 px-4 py-2 rounded-full text-xs" style={{ color: el.color }}>{el.text}</div>}
                      {el.type === 'qr' && <div className="bg-white p-2 rounded"><div className="w-8 h-8 bg-black grid grid-cols-2 gap-1 p-1"><div className="bg-white"/><div className="bg-white"/><div className="bg-white"/><div className="bg-black"/></div></div>}
                    </div>
                  ))}

                  {editorElements.length === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10 flex-col gap-4">
                       <Edit3 className="w-16 h-16" />
                       <div className="text-xs uppercase tracking-widest">Digital Canvas Active</div>
                    </div>
                  )}
               </div>

               <div className="bg-dark-2 border border-white/7 rounded-R p-5 overflow-y-auto">
                  <div className="text-[10px] font-bold uppercase text-white/30 mb-4">Properties</div>
                  {selectedElIdx !== null ? (
                    <div className="space-y-4">
                       <div className="field">
                        <label>Content</label>
                        <input 
                          value={editorElements[selectedElIdx].text}
                          onChange={e => {
                            const newEls = [...editorElements];
                            newEls[selectedElIdx].text = e.target.value;
                            setEditorElements(newEls);
                          }}
                        />
                      </div>
                      <div className="field">
                        <label>Size: {editorElements[selectedElIdx].size}px</label>
                        <input 
                          type="range" min="10" max="80" 
                          value={editorElements[selectedElIdx].size}
                          onChange={e => {
                            const newEls = [...editorElements];
                            newEls[selectedElIdx].size = parseInt(e.target.value);
                            setEditorElements(newEls);
                          }}
                          className="accent-lime"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2 mt-4">
                        {['#ffffff', '#b8ff35', '#ff3355', '#00e5cc', '#ffb020'].map(c => (
                          <div 
                            key={c} 
                            onClick={() => {
                              const newEls = [...editorElements];
                              newEls[selectedElIdx].color = c;
                              setEditorElements(newEls);
                              setEditorClr(c);
                            }}
                            className={`w-6 h-6 rounded-full cursor-pointer border-2 transition-all ${editorElements[selectedElIdx].color === c ? 'border-white scale-110' : 'border-transparent'}`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-[11px] text-white/20 italic">Select an element to edit properties</div>
                  )}
                  
                  <div className="h-px bg-white/5 my-6" />
                  <div className="text-[10px] font-bold uppercase text-white/30 mb-2">Canvas Bg</div>
                  <div className="flex flex-wrap gap-2">
                    {['#16162a', '#080810', '#0a1a10', '#1a0810'].map(c => (
                      <div key={c} onClick={() => setCanvasBg(c)} className={`w-8 h-8 rounded border-2 cursor-pointer ${canvasBg === c ? 'border-lime' : 'border-transparent'}`} style={{ backgroundColor: c }} />
                    ))}
                  </div>
               </div>
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s5')}><ArrowLeft className="w-4 h-4" /> Back to mockups</button>
               <button className="btn btn-p" onClick={() => { showToast("Creative Applied!"); nav('s5') }}>Save & Apply <ArrowRight className="w-4 h-4" /></button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S7: CONFIRM --- */}
      {currentScreen === 's7' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s7" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Review</div>
            <div className="ptitle">Launch Checklist</div>
            <div className="psub">Check everything before we broadcast your campaign to local dealers.</div>

            <div className="bg-dark-2 border border-white/10 rounded-R overflow-hidden mb-6 shadow-2xl">
              <div className="bg-lime p-7 text-black">
                <div className="font-syne text-3xl font-extrabold tracking-tight">Campaign Brief</div>
                <div className="text-[12px] opacity-60 font-semibold mt-1">ID · GENERATING ON SUBMIT</div>
              </div>
              <div className="p-8">
                {[
                  { l: 'Advertiser', v: state.name },
                  { l: 'Mobile', v: state.phone },
                  { l: 'Objective', v: state.adType },
                  { l: 'Areas', v: state.areas.join(', ') },
                  { l: 'Screens', v: `${state.slots} positions selected` },
                  { l: 'Display', v: state.displayType },
                  { l: 'Period', v: state.period },
                  { l: 'Coupon', v: state.couponDiscount > 0 ? `${state.coupon} (-${state.couponDiscount}%)` : 'None applied', c: 'text-lime' },
                ].map((row, i) => (
                  <div key={i} className="flex justify-between items-center py-3.5 border-b border-white/5 last:border-b-0">
                    <span className="text-[13px] text-white/40">{row.l}</span>
                    <span className={`text-sm font-medium ${row.c || 'text-white'}`}>{row.v || '—'}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center pt-8 mt-4 border-t-2 border-white/10 border-dashed">
                  <span className="text-sm font-semibold text-white/70">Total Estimated Budget</span>
                  <span className="font-syne text-4xl font-extrabold text-lime">₹{calculatePrice().toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="bg-dark-3 border border-white/13 border-l-[3px] border-l-lime/40 rounded-r p-5 text-[13px] text-white/50 leading-relaxed mb-8 flex gap-4">
               <Zap className="w-5 h-5 text-lime/60 shrink-0" />
               Your campaign logic is locked. Once submitted, we connect you to premium vendors who manage physical screen inventory.
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s5')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-p px-10 py-4 text-base" onClick={submitCampaign}>
                 Submit Campaign <Send className="w-5 h-5 ml-1" />
               </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* --- S8: DEALERS / SUCCESS --- */}
      {currentScreen === 's8' && (
        <div className="flex flex-col min-h-screen">
          <TopBar id="s8" />
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Connect</div>
            <div className="ptitle">Verified Dealers</div>
            <div className="psub">Your campaign is live in our system. Send your brief to verified owners to finalize dates and payment.</div>

            <div className="bg-lime/10 border border-lime/20 rounded-R p-6 flex items-center gap-5 mb-8">
               <div className="w-12 h-12 rounded-full bg-lime/20 flex items-center justify-center text-lime">
                  <Check className="w-6 h-6" />
               </div>
               <div>
                  <div className="text-sm font-bold text-white">Campaign <span className="text-lime">{state.campaignId}</span> Active</div>
                  <div className="text-[13px] text-white/40 mt-0.5">Share with dealers below to get quotes within 24 hours.</div>
               </div>
            </div>

            <div className="flex flex-col gap-4 mb-4">
              <div className="flex justify-between items-center bg-dark-2 p-4 rounded-R border border-white/5 mb-2">
                <div>
                  <div className="text-sm font-bold">Unlocking verified budget-friendly dealers...</div>
                  <div className="text-[11px] text-white/40">Access our exclusive network of high-ROI nominal rate owners.</div>
                </div>
                {!isMarketplaceUnlocked && (
                  <button onClick={handleUnlockMarketplace} className="btn btn-p px-6 py-2 text-[11px] uppercase tracking-widest font-bold">Unlock Access — ₹499</button>
                )}
              </div>
              <div className="flex gap-2">
                {(['All', 'Premium', 'Nominal'] as const).map(t => (
                  <button 
                    key={t} 
                    onClick={() => {
                        if (!isMarketplaceUnlocked && t === 'Nominal') {
                            showToast("Subscribe to browse nominal rate dealers", true);
                            return;
                        }
                        setDealerFilter(t);
                    }}
                    className={`px-4 py-1.5 rounded-full text-[11px] font-bold tracking-widest uppercase transition-all ${dealerFilter === t ? 'bg-lime text-black' : 'bg-dark-3 text-white/40 border border-white/5'} ${!isMarketplaceUnlocked && t === 'Nominal' ? 'opacity-30' : ''}`}
                  >
                    {t} Rates {!isMarketplaceUnlocked && t === 'Nominal' && <Lock className="w-3 h-3 inline ml-1" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-4 mb-10 relative">
              {dealers
                .filter(d => dealerFilter === 'All' || d.tier === dealerFilter)
                .map((dealer, i) => {
                    const isBlurred = !isMarketplaceUnlocked && dealer.tier === 'Nominal';
                    return (
                        <div key={i} className={`bg-dark-3 border border-white/10 rounded-R p-6 flex items-center gap-6 group hover:border-white/30 transition-all ${isBlurred ? 'blur-md pointer-events-none' : ''}`}>
                             {/* Content Same as Before */}
                             <div className="w-14 h-14 rounded-r bg-dark-4 border border-white/10 flex items-center justify-center font-syne text-xl font-extrabold text-lime">
                                {dealer.name.split(' ').map(w => w[0]).join('').slice(0, 2)}
                            </div>
                            <div className="flex-1">
                                <div className="text-base font-semibold mb-1 group-hover:text-lime transition-colors">{dealer.name}</div>
                                <div className="text-[12px] text-white/40 mb-3">{dealer.areas}</div>
                                <div className="flex flex-wrap gap-2">
                                {dealer.stats.map(s => <span key={s} className={`bg-dark-4 border border-white/5 rounded-full px-3 py-1 text-[10px] font-bold ${s.includes('Premium') ? 'text-cyan' : s.includes('Nominal') ? 'text-amber-500' : 'text-white/50'}`}>{s}</span>)}
                                {dealer.tier && <span className={`border rounded-full px-3 py-1 text-[10px] font-bold ${dealer.tier === 'Premium' ? 'bg-cyan/10 border-cyan/40 text-cyan' : 'bg-amber-500/10 border-amber-500/40 text-amber-500'}`}>{dealer.tier}</span>}
                                </div>
                            </div>
                            <button className="btn btn-s py-2 px-6 text-xs whitespace-nowrap hover:bg-lime hover:text-black hover:border-lime" onClick={() => contactDealer(dealer.id, state.campaignId)}>Contact Dealer</button>
                        </div>
                    );
                })}
                {!isMarketplaceUnlocked && dealerFilter === 'All' && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm rounded-R border border-white/10 h-[300px] mt-[100px] z-20">
                         <div className="text-center p-8 bg-dark-2 rounded-R border border-white/10 shadow-3xl max-w-[320px]">
                            <Lock className="w-8 h-8 text-lime mx-auto mb-3" />
                            <div className="font-syne text-xl font-extrabold mb-2">Budget Vendors Hidden</div>
                            <p className="text-xs text-white/40 mb-6 font-medium">We've identified 12 vendors matching your budget in these areas. Pay a small one-time fee to unlock their contact details.</p>
                            <button onClick={handleUnlockMarketplace} className="btn btn-p w-full justify-center">Unlock All 12 Vendors — ₹499</button>
                            <div className="mt-4 text-[10px] text-white/20 uppercase tracking-widest flex items-center justify-center gap-2">
                                <DollarSign className="w-3 h-3" /> Money-back guarantee
                            </div>
                         </div>
                    </div>
                )}
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s7')}><ArrowLeft className="w-4 h-4" /> Back</button>
               <button className="btn btn-s" onClick={resetAll}>New Campaign</button>
            </div>
          </motion.div>
        </div>
      )}
      {/* --- S10: DEALER DASHBOARD --- */}
      {currentScreen === 's10' && loggedInDealer && (
        <div className="flex flex-col min-h-screen">
          <div className="topbar">
            <div className="tlogo">AdSlot</div>
            <div className="text-xs text-white/40 font-semibold tracking-wider uppercase">Dealer Dashboard</div>
            <div className="flex gap-4 items-center">
              <span className="text-xs text-white/60">{loggedInDealer.name}</span>
              <button onClick={() => { setLoggedInDealer(null); nav('s0'); }} className="text-red-500 hover:text-red-400 transition-colors"><LogOut className="w-4 h-4" /></button>
            </div>
          </div>
          <div className="pgw">
            <div className="grid md:grid-cols-[240px_1fr] gap-8">
               {/* Sidebar */}
               <div className="flex flex-col gap-2">
                  <div className="p-3 bg-lime/10 text-lime border border-lime/20 rounded-r text-sm font-bold flex items-center gap-2 cursor-pointer">
                    <LayoutDashboard className="w-4 h-4" /> Overview
                  </div>
                  <div className="p-3 bg-dark-3 text-white/40 border border-white/5 rounded-r text-sm font-bold flex items-center gap-2 cursor-pointer hover:bg-dark-4 hover:text-white transition-all">
                    <BarChart3 className="w-4 h-4" /> Analytics
                  </div>
                  <div className="p-3 bg-dark-3 text-white/40 border border-white/5 rounded-r text-sm font-bold flex items-center gap-2 cursor-pointer hover:bg-dark-4 hover:text-white transition-all">
                    <CreditCard className="w-4 h-4" /> Billing
                  </div>
                  <div className="p-3 bg-dark-3 text-white/40 border border-white/5 rounded-r text-sm font-bold flex items-center gap-2 cursor-pointer hover:bg-dark-4 hover:text-white transition-all">
                    <Settings className="w-4 h-4" /> Profile Settings
                  </div>
               </div>

               {/* Main Content */}
               <div className="flex flex-col gap-6">
                  {/* Status Bar */}
                  <div className="bg-dark-2 border border-white/10 rounded-R p-6 flex items-center justify-between gap-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${loggedInDealer.isSubscribed ? 'bg-lime/20 text-lime' : 'bg-amber-500/10 text-amber-500'}`}>
                        {loggedInDealer.isSubscribed ? <Check className="w-6 h-6" /> : <DollarSign className="w-6 h-6" />}
                      </div>
                      <div>
                        <div className="font-bold text-lg">{loggedInDealer.isSubscribed ? 'Active Subscription' : 'Subscription Expired'}</div>
                        <div className="text-xs text-white/40">{loggedInDealer.isSubscribed ? `Renews on ${loggedInDealer.subscriptionExpiry}` : 'Your listing is hidden from the public map'}</div>
                      </div>
                    </div>
                    {!loggedInDealer.isSubscribed && (
                      <button onClick={handleSubscribe} className="btn btn-p px-6 py-2 text-xs">Renew Listing</button>
                    )}
                  </div>

                  {/* Profile Summary */}
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="bg-dark-3 border border-white/5 rounded-R p-5">
                      <div className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Dealer Code</div>
                      <div className="font-syne text-xl font-bold text-lime">{loggedInDealer.dealerCode}</div>
                    </div>
                    <div className="bg-dark-3 border border-white/5 rounded-R p-5">
                      <div className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Pricing Tier</div>
                      <div className={`font-syne text-xl font-bold ${loggedInDealer.tier === 'Premium' ? 'text-cyan' : 'text-amber-500'}`}>{loggedInDealer.tier}</div>
                    </div>
                    <div className="bg-dark-3 border border-white/5 rounded-R p-5">
                      <div className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Inquiries</div>
                      <div className="font-syne text-xl font-bold text-white">{dashboardData?.inquiries.length || 0}</div>
                    </div>
                  </div>

                  {/* Inquiries */}
                  <div className="mt-4">
                    <div className="font-syne text-xl font-bold mb-4">Latest Inquiries</div>
                    <div className="flex flex-col gap-4">
                      {dashboardData?.inquiries.length === 0 ? (
                        <div className="bg-dark-2 border border-white/5 rounded-R p-10 text-center text-white/20">
                          <Eye className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <div className="text-sm">No inquiries yet. Active campaigns will show up here.</div>
                        </div>
                      ) : (
                        dashboardData?.inquiries.map((inq, i) => (
                          <div key={i} className="bg-dark-3 border border-white/10 rounded-R p-5 flex items-center justify-between">
                            <div>
                              <div className="text-sm font-bold text-lime">{inq.campaign?.name || 'Anonymous Campaign'}</div>
                              <div className="text-[11px] text-white/40 mt-1">ID: {inq.campaignId} • Received: {new Date(inq.timestamp).toLocaleDateString()}</div>
                              <div className="flex gap-2 mt-2">
                                <span className="bg-dark-4 text-[9px] font-bold px-2 py-0.5 rounded text-white/60 border border-white/5 uppercase">Type: {inq.campaign?.adType}</span>
                                <span className="bg-dark-4 text-[9px] font-bold px-2 py-0.5 rounded text-white/60 border border-white/5 uppercase">Period: {inq.campaign?.period}</span>
                              </div>
                            </div>
                            <button className="btn btn-s text-xs py-2" onClick={() => showToast("Contacting advertiser...")}>View Details</button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* --- S11: DEALER LOGIN --- */}
      {currentScreen === 's11' && (
        <div className="flex flex-col min-h-screen items-center justify-center p-6">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[radial-gradient(circle,rgba(184,255,53,0.04)_0%,transparent_65%)] pointer-events-none" />
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-dark-2 border border-white/10 rounded-R p-8 w-full max-w-[400px] shadow-2xl relative z-10">
            <div className="tlogo mb-8 text-center text-3xl">AdSlot Dealer</div>
            <div className="space-y-4">
              <div className="field">
                <label>Dealer Email</label>
                <div className="relative">
                   <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                   <input 
                    className="pl-11"
                    type="email" 
                    placeholder="skyline@demo.com" 
                    value={loginForm.email}
                    onChange={e => setLoginForm(s => ({ ...s, email: e.target.value }))}
                   />
                </div>
              </div>
              <div className="field">
                <label>Password</label>
                <div className="relative">
                   <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                   <input 
                    className="pl-11"
                    type="password" 
                    placeholder="••••••••" 
                    value={loginForm.password}
                    onChange={e => setLoginForm(s => ({ ...s, password: e.target.value }))}
                   />
                </div>
              </div>
              <button onClick={handleDealerLogin} className="btn btn-p w-full justify-center py-4 mt-6 text-base font-bold">Log In to Dashboard</button>
              <div className="text-center mt-6">
                 <span className="text-xs text-white/20">Don't have an account? </span>
                 <button onClick={() => nav('s9')} className="text-xs text-lime font-bold hover:underline">Apply to Partner</button>
              </div>
            </div>
          </motion.div>
          <button onClick={() => nav('s0')} className="mt-8 text-white/20 text-xs flex items-center gap-2 hover:text-white transition-all"><ArrowLeft className="w-3 h-3" /> Back to Advertiser Portal</button>
        </div>
      )}
      {/* --- S12: DEALER ONBOARDING SUCCESS / RECEIPT --- */}
      {currentScreen === 's12' && onboardedDealer && (
        <div className="flex flex-col min-h-screen items-center justify-center p-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-dark-2 border border-white/10 rounded-R p-8 w-full max-w-[500px] shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-lime opacity-5 -rotate-45 translate-x-16 -translate-y-16" />
             <div className="flex items-center gap-4 mb-8">
               <div className="w-12 h-12 rounded-full bg-lime/20 flex items-center justify-center text-lime">
                 <Check className="w-6 h-6" />
               </div>
               <div>
                 <div className="text-sm font-bold text-white/40 uppercase tracking-widest">Application Successful</div>
                 <div className="font-syne text-2xl font-extrabold text-white">Partner Receipt</div>
               </div>
             </div>

             <div className="bg-dark-3 rounded-r p-6 mb-8 border border-white/5 space-y-4">
                <div className="flex justify-between border-b border-white/5 pb-3">
                  <span className="text-xs text-white/40">Partner Name</span>
                  <span className="text-sm font-bold">{onboardedDealer.name}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-3">
                  <span className="text-xs text-white/40">Dealer Code</span>
                  <span className="text-sm font-bold text-lime">{onboardedDealer.dealerCode}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-3">
                  <span className="text-xs text-white/40">Status</span>
                  <span className="text-[10px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded font-bold uppercase">Pending Verification</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-white/40">Dashboard URL</span>
                  <span className="text-[10px] text-cyan font-mono">/dealer/login</span>
                </div>
             </div>

             <div className="bg-lime/5 border border-lime/10 rounded p-4 text-[12px] text-white/60 leading-relaxed mb-8">
                <Zap className="w-4 h-4 text-lime inline mb-1 mr-1" />
                <strong>Next Step:</strong> Log in to your dashboard to activate your subscription. Listings are hidden until the first monthly payment is processed.
             </div>

             <div className="flex gap-3">
                <button onClick={() => nav('s11')} className="btn btn-p flex-1 justify-center">Log in to Dashboard</button>
                <button onClick={() => nav('s0')} className="btn btn-s">Home</button>
             </div>
          </motion.div>
        </div>
      )}

      {/* --- S9: DEALER ONBOARDING --- */}
      {currentScreen === 's9' && (
        <div className="flex flex-col min-h-screen">
          <div className="topbar">
            <div className="tlogo">AdSlot</div>
            <div className="text-xs text-white/40 font-semibold tracking-wider uppercase">Dealer Portal</div>
            <div className="flex items-center gap-4">
               <button onClick={() => nav('s11')} className="text-xs font-bold text-lime hover:underline">Existing Partner? Login</button>
               <div className="tright">Partner with us</div>
            </div>
          </div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pg">
            <div className="slabel">Partnership</div>
            <div className="ptitle">Onboard your inventory</div>
            <div className="psub">Connect your digital screens to our network and start receiving campaign briefs.</div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="field">
                <label>Company/Dealer Name</label>
                <input value={dealerOnboardState.companyName} onChange={e => setDealerOnboardState(s => ({ ...s, companyName: e.target.value }))} type="text" placeholder="Skyline Media" />
              </div>
              <div className="field">
                <label>Contact Phone</label>
                <input value={dealerOnboardState.contactPhone} onChange={e => setDealerOnboardState(s => ({ ...s, contactPhone: e.target.value }))} type="tel" placeholder="+91 98765 43210" />
              </div>
            </div>
            <div className="field">
              <label>Contact Email</label>
              <input value={dealerOnboardState.contactEmail} onChange={e => setDealerOnboardState(s => ({ ...s, contactEmail: e.target.value }))} type="email" placeholder="partners@skyline.com" />
            </div>
            <div className="field">
              <label>Set Password</label>
              <input value={dealerOnboardState.password} onChange={e => setDealerOnboardState(s => ({ ...s, password: e.target.value }))} type="password" placeholder="••••••••" />
            </div>

            <div className="grid md:grid-cols-2 gap-4 mt-4">
              <div className="field">
                <label>Total Digital Screens</label>
                <input value={dealerOnboardState.screenCount} onChange={e => setDealerOnboardState(s => ({ ...s, screenCount: parseInt(e.target.value) || 0 }))} type="number" min="1" />
              </div>
              <div className="field">
                <label>Pricing Tier</label>
                <select value={dealerOnboardState.pricingTier} onChange={e => setDealerOnboardState(s => ({ ...s, pricingTier: e.target.value }))}>
                  <option value="Nominal">Nominal Rates (Budget Friendly)</option>
                  <option value="Premium">Premium Locations (High Impact)</option>
                </select>
              </div>
            </div>

            <div className="field mt-4">
              <label>Covered Areas</label>
              <div className="flex flex-wrap gap-2">
                {[
                  'Hitech City', 'Banjara Hills', 'Jubilee Hills', 
                  'KPHB Colony', 'Ameerpet', 'Gachibowli', 
                  'Secunderabad', 'Airport Corridor'
                ].map(area => (
                  <div 
                    key={area}
                    onClick={() => {
                      const areas = dealerOnboardState.coveredAreas.includes(area)
                        ? dealerOnboardState.coveredAreas.filter(a => a !== area)
                        : [...dealerOnboardState.coveredAreas, area];
                      setDealerOnboardState(s => ({ ...s, coveredAreas: areas }));
                    }}
                    className={`area ${dealerOnboardState.coveredAreas.includes(area) ? 'area-on' : ''}`}
                  >
                    {area}
                  </div>
                ))}
              </div>
            </div>

            <div className="divider" />
            <div className="flex gap-3">
               <button className="btn btn-g" onClick={() => nav('s0')}><ArrowLeft className="w-4 h-4" /> Back to home</button>
               <button className="btn btn-p px-10 py-4" onClick={submitDealerOnboarding}>
                 Submit Partner Request <ArrowRight className="w-4 h-4" />
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
