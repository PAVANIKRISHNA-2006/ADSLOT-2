# AdSlot — Digital Billboard Booking

A fully static React app for booking digital billboard slots across Hyderabad. Deployable on GitHub Pages with zero backend required.

## 🚀 Deploy to GitHub Pages (one-time setup)

1. **Push this repo to GitHub**
2. Go to **Settings → Pages**
3. Under *Source*, select **GitHub Actions**
4. Push to `main` — the workflow auto-builds and deploys

Your app will be live at:  
`https://<your-username>.github.io/<repo-name>/`

## 💻 Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:5173`

## 🏗️ Build for production

```bash
npm run build
# Output is in dist/
```

## 📝 Notes

- No backend or API keys required — all data is local/in-memory
- Demo dealer login: `skyline@demo.com` / `password123`
- AI headline suggestions use smart local fallbacks (no API key needed)
